const express = require('express');
const router = express.Router();
const MovieController = require('../controller/controller');

router.post('/patients', MovieController.createArea);
router.get('/patients',  MovieController.getAllArea);
//router.put('/patients/:id', patientController.updatePatient);
router.delete('/patients/:id',  MovieController.deleteArea);

router.post('/movies',  MovieController.createMovies);
router.get('/movies',  MovieController.getMovies);
//router.put('/patients/:id', patientController.updatePatient);
router.delete('/movies/:id',  MovieController.deleteMovies);

router.post('/theatres', MovieController.createTheatres);
router.get('/theatres',  MovieController.getTheatres);
//router.put('/patients/:id', patientController.updatePatient);
router.delete('/theatres/:id', MovieController.deleteTheatres);

router.post('/registers', MovieController.createUsers);
router.get('/registers',  MovieController.getUsers);
router.delete('/registers/:id',  MovieController.deleteUsers);
//router.put('/registers/:id', patientController.updateUser);

router.post('/booked', MovieController.createBooked);
router.get('/booked',  MovieController.getBooked);
router.delete('/booked/:id',  MovieController.deleteBooked);

module.exports = router;