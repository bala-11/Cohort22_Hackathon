const mongoose = require("mongoose");
const userSchema1 = new mongoose.Schema(
    {
      name:String,
      image:String,
      time:String,
      time1:String,
      time2:String,
      time3:String,
      time4:String,
     }
  );
  module.exports = mongoose.model("movies", userSchema1);