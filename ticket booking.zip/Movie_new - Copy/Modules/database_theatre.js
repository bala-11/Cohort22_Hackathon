const mongoose = require("mongoose");

const userSchema2 = new mongoose.Schema(
  {
    name:String,
    image:String,
    location:String
   }
);
module.exports = mongoose.model("theatres", userSchema2);




