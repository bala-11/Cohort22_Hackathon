const mongoose = require("mongoose");

const userSchema4 = new mongoose.Schema(
  {
    email:String,
    theatre:String,
    movie:String,
    seats:String
   }
);
module.exports = mongoose.model("booked", userSchema4);




