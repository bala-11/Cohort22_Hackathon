const mongoose = require("mongoose");

const userSchema3 = new mongoose.Schema(
  {
    name:String,
    email:String,
    phno:String,
    password:String
   }
);
module.exports = mongoose.model("registers", userSchema3);




