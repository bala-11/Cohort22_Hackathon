window.onload=h()
window.onload=he()
var users_json="";
var areas="";
h()
function h()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/theatres", true);
	// x.setRequestHeader("Content-Type","application/json");
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				users_json = JSON.parse(x.responseText);
				console.log(users_json);
                display();
			}
		}
	}
}

function he()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/patients", true);
	// x.setRequestHeader("Content-Type","application/json");
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				areas = JSON.parse(x.responseText);
				console.log(areas);
                display();
			}
		}
	}
}

function display() 
{
	var content = " ";
    for (let i in users_json)
    {

	content += `
    <div class="product">
    <picture><img src="${users_json[i].image}" alt="">
    </picture>
    <div class="detail"><p><b>${users_json[i].name}</b><br>
    </p></div><div class="button"><a href="movi.html">SHOW MOVIES</a></div></div>
    ` 
	}
	document.getElementById('d').innerHTML = content;
    console.log(content)
    console.log(users_json)
	
}
console.log(users_json)
function val()
{
	var x=document.getElementByClassName("detail").value
	console.log(x)
}