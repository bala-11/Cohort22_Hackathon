window.onload=htt()
var users="";
function htt()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/movies", true);
	// x.setRequestHeader("Content-Type","application/json");
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				users = JSON.parse(x.responseText);
				console.log(users);
                display();
			}
		}
	}
}

function display() 
{
	var content = " ";
    for (let i in users)
    {
	content += ` <div id="mov">
    <div class="float-container">
        <div class="b1">
        <div class="green">${users[i].name}</div>
        <div class="float-child">
        <img src="${users[i].image}" class="img1">
        </div>
        </div>
    
          <div class="blue">
            <span class="box"><a href="/ticketdisplay/display.html">${users[i].time}</a></span>
            <span class="box"><a href="/ticketdisplay/display.html">${users[i].time1}</a></span>
            <span class="box"><a href="/ticketdisplay/display.html">${users[i].time2}</a></span>
            <span class="box"><a href="/ticketdisplay/display.html">${users[i].time3}</a></span>
            <span class="box"><a href="/ticketdisplay/display.html">${users[i].time4}</a></span>
          </div>
    </div>    
    </div>
     </div>
    `
    }
	document.getElementById('s').innerHTML = content;
    console.log(content)
}
