window.onload=htt()
var users="";
function htt()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/patients", true);
	// x.setRequestHeader("Content-Type","application/json");
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				users = JSON.parse(x.responseText);
				console.log(users);
                display();
			}
		}
	}
}

function display() 
{
	var content = " ";
    for (let i in users)
    {
	content += `
    <span class="container">
    <img src="${users[i].image}" alt="Avatar" class="image" >
    <div class="middle">
      <div class="text"><a href="theatre.html"style="text-decoration:none">${users[i].name}</a></div>
    </div>
</span>
    `
    }
	document.getElementById('scroll-container').innerHTML = content;
    console.log(content)
}

