const database_booked = require("../Modules/database_booked");

var users="";
function htt()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/patients", true);
	// x.setRequestHeader("Content-Type","application/json");
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				users = JSON.parse(x.responseText);
				console.log(users);
                display();
			}
		}
	}
}
function del(x) {
    console.log(x)
	var y = new XMLHttpRequest();
	y.open("DELETE", `http://localhost:2000/patients/${x}`, true);
	y.send();
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) 
            {
				htt();
			}
		}
	}
}
function addarea()
{
    var Name = document.getElementById("name").value;
	var Image=document.getElementById("img").value;
    console.log(Name)
	var y = new XMLHttpRequest();
	y.open("POST", "http://localhost:2000/patients", true);
	y.setRequestHeader("Content-Type", "application/json");
	y.send(JSON.stringify({
		"name": Name,
		"image": Image
	}))
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) {
				htt();
			}
		}
	}
}

function display() 
{
	var content = " ";
    for (let i in users)
    {
	content += `
	<span><span id="root">${users[i].name}</span>
    <button onclick='del("${users[i]._id}")'>Delete</button><br>
	</span>
    `
    }
	document.getElementById('root').innerHTML = content;
}

//Movies

var movies="";
function ht()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/movies", true);
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				movies = JSON.parse(x.responseText);
				console.log(movies);
                display1();
			}
		}
	}
}
function de(x) {
    console.log(x)
	var y = new XMLHttpRequest();
	y.open("DELETE", `http://localhost:2000/movies/${x}`, true);
	y.send();
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) 
            {
				ht();
			}
		}
	}
}
function addmovie()
{
    var Name = document.getElementById("name1").value;
	var Image = document.getElementById("img1").value;
	var Time1 = document.getElementById("time1").value;
	var Time2 = document.getElementById("time2").value;
	var Time3 = document.getElementById("time3").value;
	var Time4 = document.getElementById("time4").value;
	var Time5 = document.getElementById("time5").value;

    console.log(Name)
	var y = new XMLHttpRequest();
	y.open("POST", "http://localhost:2000/movies", true);
	y.setRequestHeader("Content-Type", "application/json");
	y.send(JSON.stringify({
		"name": Name,
		"image":Image,
		"time":Time1,
		"time1":Time2,
		"time2":Time3,
		"time3":Time4,
		"time4":Time5,
	}))
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) {
				ht();
			}
		}
	}
}


function display1() 
{
	var content = " ";
    for (let i in movies)
    {
	content += `
	<span>
	<span id="root1">${movies[i].name}</span>

    <button onclick='de("${movies[i]._id}")'>Delete</button><br>
	</span>
    `
    }
	document.getElementById('root1').innerHTML = content;
}
var dis=document.getElementById('b').value;
var disp1=document.getElementById('z').value;
if(dis.style.display = 'none'){
disp1.style.display = 'block'
}



//Theatre

var theatres="";
function ht1()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/theatres", true);
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				theatres = JSON.parse(x.responseText);
				console.log(theatres);
                display2();
			}
		}
	}
}
function dele(x) {
    console.log(x)
	var y = new XMLHttpRequest();
	y.open("DELETE", `http://localhost:2000/theatres/${x}`, true);
	y.send();
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) 
            {
				ht1();
			}
		}
	}
}
function addtheatre()
{
    var Name = document.getElementById("name2").value;
	var Image=document.getElementById("img4").value;
	var Location=document.getElementById("loc").value;
    console.log(Name)
	var y = new XMLHttpRequest();
	y.open("POST", "http://localhost:2000/theatres", true);
	y.setRequestHeader("Content-Type", "application/json");
	y.send(JSON.stringify({
		"name": Name,
		"image":Image,
		"location":Location
	}))
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) {
				ht1();
			}
		}
	}
}


function display2() 
{
	var content = " ";
    for (let i in theatres)
    {
	content += `
	<span>
	<span id="root1">${theatres[i].name}</span>
    <button onclick='dele("${theatres[i]._id}")'>Delete</button><br>
	</span>
    `
    }
	document.getElementById('root2').innerHTML = content;
}

//REGISTERS
var registers=""

function adduser()
{
    var Name = document.getElementById("name3").value;
	var Email=document.getElementById("email3").value;
    var Phone=document.getElementById("phnno3").value;
    var Password=document.getElementById("pass3").value;
	var y = new XMLHttpRequest();
	y.open("POST", "http://localhost:2000/registers", true);
	y.setRequestHeader("Content-Type", "application/json");
	y.send(JSON.stringify({
		"name": Name,
		"email":Email,
		"phno":Phone,
		"password":Password
	}))
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) {
				ht11();
			}
		}
	}
}
function delete1(x) {
    console.log(x)
	var y = new XMLHttpRequest();
	y.open("DELETE", `http://localhost:2000/registers/${x}`, true);
	y.send();
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) 
            {
				ht11();
			}
		}
	}
}
function ht11()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/registers", true);
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				registers = JSON.parse(x.responseText);
				console.log(registers);
				display3()
			}
		}
	}
}

function display3() 
{
	var content = " ";
    for (let i in registers)
    {
	content += `
	<span>
	<span id="root3">${registers[i].name}</span>
	<span id="root3">${registers[i].email}</span>
	<span id="root3">${registers[i].phno}</span>
	<span id="root3">${registers[i].password}</span>
    <button onclick='delete1("${registers[i]._id}")'>Delete</button><br>
	</span>
    `
    }
	document.getElementById('root3').innerHTML = content;
}
//BOOOKED
var booked=""
function ht12()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/booked", true);
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				booked = JSON.parse(x.responseText);
				console.log(booked);
				display4()
			}
		}
	}
}
function delete2(x) {
    console.log(x)
	var y = new XMLHttpRequest();
	y.open("DELETE", `http://localhost:2000/booked/${x}`, true);
	y.send();
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) 
            {
				ht12();
			}
		}
	}
}


function display4() 
{
	var content = " ";
    for (let i in booked)
    {
	content += `
	<span>
	<span id="root4">${booked[i].email}</span>
	<span id="root4">${booked[i].theatre}</span>
	<span id="root4">${booked[i].movie}</span>
	<span id="root4">${booked[i].seats}</span>
    <button onclick='delete2("${booked[i]._id}")'>Delete</button><br>
	</span>
    `
    }
	document.getElementById('root4').innerHTML = content;
}
function addbooked()
{
    var Email = document.getElementById("name4").value;
	var Phone=document.getElementById("email4").value;
    var Password=document.getElementById("phno4").value;
    var Theatre=document.getElementById("pass4").value;
	var y = new XMLHttpRequest();
	y.open("POST", "http://localhost:2000/booked", true);
	y.setRequestHeader("Content-Type", "application/json");
	y.send(JSON.stringify({
		"email":Email,
		"movie":Phone,
		"seats":Password,
		"theatre":Theatre
	}))
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) {
				ht12();
			}
		}
	}
}