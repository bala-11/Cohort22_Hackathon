window.onload=ht()
var users="";
var flag=0;
function ht()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/registers", true);
	// x.setRequestHeader("Content-Type","application/json");
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				users = JSON.parse(x.responseText);
				console.log(users);
                //display();
			}
		}
	}
}
function addUser()
{
    var Name = document.getElementById("name").value;
    var Email=document.getElementById("email").value;
    var Phone=document.getElementById("phno").value;
    var Password=document.getElementById("password").value;
    console.log(Name)
    console.log(Email)
	for(let i in users)
	{
       if(users[i].name==Name)
	   {
		console.log("user already exists");
        flag=1;
	   }
	   else
	   {
		flag=0;
	   }
	}
	if(flag==0)
	{
	var y = new XMLHttpRequest();
	y.open("POST", "http://localhost:2000/registers", true);
	y.setRequestHeader("Content-Type", "application/json");
	y.send(
        JSON.stringify({
		"name": Name,
        "email":Email,
        "phno":Phone,
        "password":Password
	}))
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) {
				ht();
                //display()
			}
		}
	}
}

}





