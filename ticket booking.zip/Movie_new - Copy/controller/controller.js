const db = require('../Modules/database');
const db1=require('../Modules/database1');
const db2=require('../Modules/database_theatre')
const db3=require('../Modules/database_registers')
const db4=require('../Modules/database_booked')

// .......................GET ALL USERS..................

exports.getAllArea = (req, res) => 
{
  db.find({}) 
  .then(docs => 
  {
      console.log(docs)
      res.json(docs) 
  })
  .catch(err => console.log("Error in fetching the users",err))
}

exports.deleteArea = async (req, res) => {
    try{
      const patientId = req.params.id;
      console.log(patientId);
      var g=await db.findByIdAndDelete(patientId);
      res.send("Deleted successfully");
    }
    catch(error)
    {
        console.log("Error in deleting the patient's profile",error);
    }
    }

//...........................ADD A NEW USER.............

exports.createArea = async (req, res) => {
    const {name}= req.body;
    const {image}= req.body;
    try{
    const d={name,image}
    var k= new db(d).save();
    res.status(200).json(req.body);
    }
    catch(error)
    {
    console.log("Error in adding a new patient",error)
    }
    }


// .......................GET ALL USERS..................

exports.getMovies = (req, res) => 
{
  db1.find({}) 
  .then(docs => 
  {
      console.log(docs)
      res.json(docs) 
  })
  .catch(err => console.log("Error in fetching the users",err))
}

exports.deleteMovies = async (req, res) => {
    try{
      const patientId = req.params.id;
      console.log(patientId);
      var g=await db1.findByIdAndDelete(patientId);
      res.send("Deleted successfully");
    }
    catch(error)
    {
        console.log("Error in deleting the patient's profile",error);
    }
    }

//...........................ADD A NEW USER.............

exports.createMovies = async (req, res) => {
    const {name}= req.body;
    const {image}=req.body;
    const {time}=req.body;
    const {time1}=req.body;
    const {time2}=req.body;
    const {time3}=req.body;
    const {time4}=req.body;

    try{
    const d={name,image,time,time1,time2,time3,time4}
    var k= new db1(d).save();
    res.status(200).json(req.body);
    }
    catch(error)
    {
    console.log("Error in adding a new patient",error)
    }
    }

    //theatres
    // .......................GET ALL USERS..................

exports.getTheatres = (req, res) => 
{
  db2.find({}) 
  .then(docs => 
  {
      console.log(docs)
      res.json(docs) 
  })
  .catch(err => console.log("Error in fetching the users",err))
}

exports.deleteTheatres = async (req, res) => {
    try{
      const patientId = req.params.id;
      console.log(patientId);
      var g=await db2.findByIdAndDelete(patientId);
      res.send("Deleted successfully");
    }
    catch(error)
    {
        console.log("Error in deleting the patient's profile",error);
    }
    }

//...........................ADD A NEW USER.............

exports.createTheatres = async (req, res) => {
    const {name}= req.body;
    const {image}=req.body;
    try{
    const d={name,image}
    var k= new db2(d).save();
    res.status(200).json(req.body);
    }
    catch(error)
    {
    console.log("Error in adding a new patient",error)
    }
    }

  //REGSITERS

  exports.createUsers = async (req, res) => {
    const {name}= req.body;
    const {email}=req.body;
    const {phno}=req.body;
    const {password}=req.body;
    try{
    const d={name,email,phno,password}
    var k= new db3(d).save();
    res.status(200).json(req.body);
    }
    catch(error)
    {
    console.log("Error in adding a new patient",error)
    }
    }


    // .......................GET ALL USERS..................

exports.getUsers = (req, res) => 
{
  db3.find({}) 
  .then(docs => 
  {
      console.log(docs)
      res.json(docs) 
  })
  .catch(err => console.log("Error in fetching the users",err))
}
exports.deleteUsers = async (req, res) => {
  try{
    const patientId = req.params.id;
    console.log(patientId);
    var g=await db3.findByIdAndDelete(patientId);
    res.send("Deleted successfully");
  }
  catch(error)
  {
      console.log("Error in deleting the patient's profile",error);
  }
  }

  //booked

exports.getBooked = (req, res) => 
{
  db4.find({}) 
  .then(docs => 
  {
      console.log(docs)
      res.json(docs) 
  })
  .catch(err => console.log("Error in fetching the users",err))
}

exports.createBooked = async (req, res) => {
  const {email}= req.body;
  const {movie}=req.body;
  const {seats}=req.body;
  const {theatre}=req.body;
  try{
  const d={email,movie,seats,theatre}
  var k= new db4(d).save();
  res.status(200).json(req.body);
  }
  catch(error)
  {
  console.log("Error in adding a new patient",error)
  }
  }

  exports.deleteBooked = async (req, res) => {
    try{
      const patientId = req.params.id;
      console.log(patientId);
      var g=await db4.findByIdAndDelete(patientId);
      res.send("Deleted successfully");
    }
    catch(error)
    {
        console.log("Error in deleting the patient's profile",error);
    }
    }