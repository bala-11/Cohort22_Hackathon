
var t="";
function sub()
{
    var Email = document.getElementById("email").value;
	var Phone=document.getElementById("tname").value;
    var Password=document.getElementById("mname").value;
    var Theatre=document.getElementById("seats").value;
    console.log(Email)

 t+=`
 <h1>${Password}</h1>
 <p>${Phone}</p>
 <img src ="https://tse2.mm.bing.net/th/id/OIP.XD7adQpW6wFVzJ2IPFLtbQHaE6?w=268&h=180&c=7&r=0&o=5&pid=1.7">
 <div class="time">
     <span id="t1"><div>${Email}</div></span>

 </div>
 <div class="time">
     <span id="t1"><div>${Theatre}</div></span>

 </div>
 <div id="i1">
     <img src="https://tse2.mm.bing.net/th/id/OIP.bV3Vga8gCDTbaQ_zKVM3rQAAAA?pid=ImgDet&w=180&h=118&c=7">
 </div>`

 console.log(t)
document.getElementById('print').innerHTML=t;


	var y = new XMLHttpRequest();
	y.open("POST", "http://localhost:2000/booked", true);
	y.setRequestHeader("Content-Type", "application/json");
      var f=JSON.stringify({
		"email":Email,
		"movie":Phone,
		"seats":Password,
		"theatre":Theatre
	})
	y.send(f)
	y.onreadystatechange = function () {
		if (y.readyState == 4) {
			if (y.status == 200) {
				ht12();
                // tic()
                
			}
		}
	}
}
var booked=""
ht12()
function ht12()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/booked", true);
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				booked = JSON.parse(x.responseText);
				console.log(booked);
			}
		}
	}
}
var u=""
ht11()
function ht11()
 {
	const x = new XMLHttpRequest();
	x.open("GET", "http://localhost:2000/registers", true);
	x.send();
	x.onreadystatechange = function () {
		if (x.readyState == 4) {
			if (x.status == 200) {
				u= JSON.parse(x.responseText);
				console.log(u);
               
			}
		}
	}
}


